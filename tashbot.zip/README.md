# TashBot

Polymarket investment bot.